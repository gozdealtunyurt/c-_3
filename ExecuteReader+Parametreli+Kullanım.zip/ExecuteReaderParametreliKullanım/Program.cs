﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExecuteReaderParametreliKullanım
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection can = new SqlConnection(@"Data Source=DESKTOP-QO5MM8V\SQLEXPRESS;Initial Catalog=SQLFULL;Integrated Security=True; User Id=udemy; Password=1");
            SqlCommand command = new SqlCommand("select * from musterim where MusteriID=@ID", can);
            command.Parameters.Add("@ID", SqlDbType.Int).Value = 4;
            can.Open();
            SqlDataReader SQLReader=command.ExecuteReader();
            while (SQLReader.Read())
            {
                int MusteriID = SQLReader.GetInt32(0);
                string Isim = SQLReader.GetString(1);
                string Soyisim = SQLReader.GetString(2);
            }
            SQLReader.Close();
            can.Close();
        }
    }
}
