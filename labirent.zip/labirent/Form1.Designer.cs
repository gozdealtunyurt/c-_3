﻿namespace labirent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.finishlabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.finishlabel);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label37);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 580);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(14, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 120);
            this.label1.TabIndex = 0;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            this.label1.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(152, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 27);
            this.label2.TabIndex = 1;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            this.label2.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(89, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 27);
            this.label3.TabIndex = 2;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            this.label3.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.DarkBlue;
            this.label4.Location = new System.Drawing.Point(44, 466);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 27);
            this.label4.TabIndex = 3;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            this.label4.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(14, 379);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 27);
            this.label5.TabIndex = 4;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            this.label5.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.DarkBlue;
            this.label8.Location = new System.Drawing.Point(203, 264);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 27);
            this.label8.TabIndex = 7;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            this.label8.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.DarkBlue;
            this.label9.Location = new System.Drawing.Point(275, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 27);
            this.label9.TabIndex = 8;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            this.label9.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.DarkBlue;
            this.label11.Location = new System.Drawing.Point(374, 379);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 27);
            this.label11.TabIndex = 10;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            this.label11.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.DarkBlue;
            this.label13.Location = new System.Drawing.Point(299, 264);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(142, 27);
            this.label13.TabIndex = 12;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            this.label13.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.DarkBlue;
            this.label15.Location = new System.Drawing.Point(181, 466);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(142, 27);
            this.label15.TabIndex = 14;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            this.label15.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.DarkBlue;
            this.label16.Location = new System.Drawing.Point(424, 482);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(142, 27);
            this.label16.TabIndex = 15;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            this.label16.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.DarkBlue;
            this.label17.Location = new System.Drawing.Point(95, 293);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(142, 27);
            this.label17.TabIndex = 16;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            this.label17.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.DarkBlue;
            this.label18.Location = new System.Drawing.Point(374, 188);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(142, 27);
            this.label18.TabIndex = 17;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            this.label18.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.DarkBlue;
            this.label19.Location = new System.Drawing.Point(355, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(142, 27);
            this.label19.TabIndex = 18;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            this.label19.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.DarkBlue;
            this.label20.Location = new System.Drawing.Point(355, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(142, 27);
            this.label20.TabIndex = 19;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            this.label20.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.DarkBlue;
            this.label21.Location = new System.Drawing.Point(227, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(142, 27);
            this.label21.TabIndex = 20;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            this.label21.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.DarkBlue;
            this.label22.Location = new System.Drawing.Point(29, 208);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(142, 27);
            this.label22.TabIndex = 21;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            this.label22.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.DarkBlue;
            this.label23.Location = new System.Drawing.Point(451, 538);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(142, 27);
            this.label23.TabIndex = 22;
            this.label23.Click += new System.EventHandler(this.label23_Click);
            this.label23.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.DarkBlue;
            this.label24.Location = new System.Drawing.Point(44, 538);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(142, 27);
            this.label24.TabIndex = 23;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            this.label24.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.DarkBlue;
            this.label25.Location = new System.Drawing.Point(227, 538);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(142, 27);
            this.label25.TabIndex = 24;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            this.label25.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.DarkBlue;
            this.label26.Location = new System.Drawing.Point(339, 538);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(142, 27);
            this.label26.TabIndex = 25;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            this.label26.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.DarkBlue;
            this.label27.Location = new System.Drawing.Point(14, 256);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(34, 120);
            this.label27.TabIndex = 26;
            this.label27.Click += new System.EventHandler(this.label27_Click);
            this.label27.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.DarkBlue;
            this.label28.Location = new System.Drawing.Point(14, 138);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(34, 120);
            this.label28.TabIndex = 27;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            this.label28.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.DarkBlue;
            this.label29.Location = new System.Drawing.Point(14, 373);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 120);
            this.label29.TabIndex = 28;
            this.label29.Click += new System.EventHandler(this.label29_Click);
            this.label29.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.DarkBlue;
            this.label30.Location = new System.Drawing.Point(482, 379);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(34, 120);
            this.label30.TabIndex = 29;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            this.label30.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.DarkBlue;
            this.label31.Location = new System.Drawing.Point(559, 95);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(34, 120);
            this.label31.TabIndex = 30;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            this.label31.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.DarkBlue;
            this.label32.Location = new System.Drawing.Point(559, 322);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(34, 120);
            this.label32.TabIndex = 31;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            this.label32.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.DarkBlue;
            this.label33.Location = new System.Drawing.Point(14, 445);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(34, 120);
            this.label33.TabIndex = 32;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            this.label33.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.DarkBlue;
            this.label34.Location = new System.Drawing.Point(559, 20);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(34, 120);
            this.label34.TabIndex = 33;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            this.label34.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.DarkBlue;
            this.label35.Location = new System.Drawing.Point(559, 208);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(34, 120);
            this.label35.TabIndex = 34;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            this.label35.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.DarkBlue;
            this.label36.Location = new System.Drawing.Point(203, 264);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(34, 120);
            this.label36.TabIndex = 35;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            this.label36.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.DarkBlue;
            this.label37.Location = new System.Drawing.Point(463, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(34, 120);
            this.label37.TabIndex = 36;
            this.label37.Click += new System.EventHandler(this.label37_Click);
            this.label37.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.DarkBlue;
            this.label38.Location = new System.Drawing.Point(260, 95);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(34, 120);
            this.label38.TabIndex = 37;
            this.label38.Click += new System.EventHandler(this.label38_Click);
            this.label38.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.DarkBlue;
            this.label39.Location = new System.Drawing.Point(89, 50);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(34, 120);
            this.label39.TabIndex = 38;
            this.label39.Click += new System.EventHandler(this.label39_Click);
            this.label39.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.DarkBlue;
            this.label40.Location = new System.Drawing.Point(482, 188);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(34, 120);
            this.label40.TabIndex = 39;
            this.label40.Click += new System.EventHandler(this.label40_Click);
            this.label40.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.DarkBlue;
            this.label41.Location = new System.Drawing.Point(152, 115);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(34, 120);
            this.label41.TabIndex = 40;
            this.label41.Click += new System.EventHandler(this.label41_Click);
            this.label41.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.DarkBlue;
            this.label42.Location = new System.Drawing.Point(559, 445);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(34, 120);
            this.label42.TabIndex = 41;
            this.label42.Click += new System.EventHandler(this.label42_Click);
            this.label42.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // finishlabel
            // 
            this.finishlabel.AutoSize = true;
            this.finishlabel.Location = new System.Drawing.Point(184, 563);
            this.finishlabel.Name = "finishlabel";
            this.finishlabel.Size = new System.Drawing.Size(37, 16);
            this.finishlabel.TabIndex = 42;
            this.finishlabel.Text = "finish";
            this.finishlabel.Click += new System.EventHandler(this.finishlabel_Click);
            this.finishlabel.MouseEnter += new System.EventHandler(this.finishlabel_MouseEnter);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.DarkBlue;
            this.label6.Location = new System.Drawing.Point(203, 343);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 120);
            this.label6.TabIndex = 43;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            this.label6.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.DarkBlue;
            this.label7.Location = new System.Drawing.Point(361, 322);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 120);
            this.label7.TabIndex = 44;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            this.label7.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.DarkBlue;
            this.label10.Location = new System.Drawing.Point(270, 379);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 27);
            this.label10.TabIndex = 45;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            this.label10.MouseEnter += new System.EventHandler(this.label35_MouseEnter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 603);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "labirent";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label finishlabel;
    }
}

