﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JasonOrnek
{
    class Kitap
    {
        public string baslik { get; set; }
        public decimal fiyat { get; set; }
    }
}
