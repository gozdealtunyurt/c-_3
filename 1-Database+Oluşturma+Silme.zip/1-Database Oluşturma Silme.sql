﻿create database Ornek2
-- create database komutu ile yeni bir databae oluşturulur

drop database Ornek2
--drop database komutunu kullanarak olan database i siliyoruz

CREATE database SQLFULL