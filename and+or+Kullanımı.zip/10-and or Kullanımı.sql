select * from DimProduct

select * from DimProduct
where 
color = 'Yellow'
and ProductSubcategoryKey='14'


select * from DimProduct
where 
color = 'Yellow'
and ProductSubcategoryKey='14'

select * from DimProduct
where 
color = 'Yellow'
or color='Blue'