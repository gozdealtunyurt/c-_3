﻿namespace pinpon_topu
{
    partial class gameform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.playround = new System.Windows.Forms.Panel();
            this.gameover_lbl = new System.Windows.Forms.Label();
            this.points = new System.Windows.Forms.Label();
            this.skor_lbl = new System.Windows.Forms.Label();
            this.ball = new System.Windows.Forms.PictureBox();
            this.racket = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.playround.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.racket)).BeginInit();
            this.SuspendLayout();
            // 
            // playround
            // 
            this.playround.Controls.Add(this.gameover_lbl);
            this.playround.Controls.Add(this.points);
            this.playround.Controls.Add(this.skor_lbl);
            this.playround.Controls.Add(this.ball);
            this.playround.Controls.Add(this.racket);
            this.playround.Dock = System.Windows.Forms.DockStyle.Fill;
            this.playround.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.playround.Location = new System.Drawing.Point(0, 0);
            this.playround.Name = "playround";
            this.playround.Size = new System.Drawing.Size(800, 450);
            this.playround.TabIndex = 0;
            // 
            // gameover_lbl
            // 
            this.gameover_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gameover_lbl.Location = new System.Drawing.Point(262, 73);
            this.gameover_lbl.Name = "gameover_lbl";
            this.gameover_lbl.Size = new System.Drawing.Size(496, 190);
            this.gameover_lbl.TabIndex = 4;
            this.gameover_lbl.Text = "GAME OVER\r\nF1-RESTALT GAME\r\nESC-EXİT \r\n";
            // 
            // points
            // 
            this.points.AutoSize = true;
            this.points.Location = new System.Drawing.Point(193, 18);
            this.points.Name = "points";
            this.points.Size = new System.Drawing.Size(63, 69);
            this.points.TabIndex = 3;
            this.points.Text = "0";
            this.points.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // skor_lbl
            // 
            this.skor_lbl.AutoSize = true;
            this.skor_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.skor_lbl.Location = new System.Drawing.Point(12, 18);
            this.skor_lbl.Name = "skor_lbl";
            this.skor_lbl.Size = new System.Drawing.Size(193, 69);
            this.skor_lbl.TabIndex = 2;
            this.skor_lbl.Text = "score:";
            // 
            // ball
            // 
            this.ball.BackColor = System.Drawing.Color.Red;
            this.ball.Location = new System.Drawing.Point(345, 321);
            this.ball.Name = "ball";
            this.ball.Size = new System.Drawing.Size(30, 30);
            this.ball.TabIndex = 1;
            this.ball.TabStop = false;
            // 
            // racket
            // 
            this.racket.BackColor = System.Drawing.Color.Black;
            this.racket.Location = new System.Drawing.Point(266, 399);
            this.racket.Name = "racket";
            this.racket.Size = new System.Drawing.Size(200, 20);
            this.racket.TabIndex = 0;
            this.racket.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // gameform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.playround);
            this.Name = "gameform";
            this.Text = "Pink-Ponk Game";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gameform_KeyDown);
            this.playround.ResumeLayout(false);
            this.playround.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.racket)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel playround;
        private System.Windows.Forms.Label gameover_lbl;
        private System.Windows.Forms.Label points;
        private System.Windows.Forms.Label skor_lbl;
        private System.Windows.Forms.PictureBox ball;
        private System.Windows.Forms.PictureBox racket;
        private System.Windows.Forms.Timer timer1;
    }
}

