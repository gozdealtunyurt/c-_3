﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pinpon_topu
{
    public partial class gameform : Form
    {
        public int speedleft = 4;
        public int speedtop = 4;
        public int skor = 0;

        public gameform()
        {
            InitializeComponent();
            timer1.Enabled = true;
            Cursor.Hide();
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;//uyg dan gelsin aklına, en üste çıkarıyor ekranı. Diğer uyg da üstüne çıkarıyor.
            this.Bounds = Screen.PrimaryScreen.Bounds;//tam ekran olmasını sağlar,system.drawing de Rectangle yapısı kullanılır.Bu dikd. konumunu kullanarak yer ve konum belirtir.
            racket.Top = playround.Bottom - (playround.Height / 10);//bottom yazınca da ooluyor height yerine ama bana mantık olarak bottomdan daha mantıklı geldi sonuc olarak yüksekliğin onda biirini çıkarıyoruz ve o oyun cubugunu da bottom olarak en dibe yerlestirip üzerine daha sonra yüksekliğin onda birini düşünoruz :d
            gameover_lbl.Left = (playround.Width / 2) - (gameover_lbl.Width / 2);
            gameover_lbl.Top = (playround.Height / 2) - (gameover_lbl.Height / 2);
            gameover_lbl.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            racket.Left = Cursor.Position.X - (racket.Width / 2);
            ball.Left += speedleft;
            ball.Top = speedtop;
            if (ball.Left <= playround.Left)
            {
                speedleft = -speedleft;
            }
            if (ball.Right >= playround.Right)
            {
                speedleft = -speedleft;
            }
            if (ball.Top <= playround.Top)
            {
                speedtop = -speedtop;
            }
            if (ball.Bottom >= playround.Bottom)
            {
                gameover_lbl.Visible = true;
                timer1.Enabled = false;
            }
            if (ball.Left <= playround.Left && ball.Right >= playround.Right && ball.Top <= playround.Top && ball.Bottom >= playround.Bottom)
            {
                speedtop += 2;
                speedleft += 2;
                speedtop = -speedtop;
                skor += 1;
                points.Text = skor.ToString();

                Random rnd = new Random();
                playround.BackColor = Color.FromArgb(rnd.Next(150, 225), rnd.Next(150, 225), rnd.Next(150, 225));
            }
        }

        private void gameform_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
            if (e.KeyCode == Keys.F1)
            {
                ball.Top = 50;
                ball.Left = 50;
                speedleft = 4;
                points.Text = "0";
                timer1.Enabled = true;
                gameover_lbl.Visible = false;
                playround.BackColor = Color.White;
            }
        }
    }
}
