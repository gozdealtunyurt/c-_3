﻿--where : Verilerimi getirmek istediğim kriterlere göre getirdiğimde kullandığım yapı

select ProductAlternateKey,ProductSubcategoryKey
 from DimProduct
where ProductKey='1'