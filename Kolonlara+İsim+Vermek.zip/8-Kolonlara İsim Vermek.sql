Select * from DimProduct

select ProductAlternateKey as UrunAnahtar,
EnglishProductName AS [Ingiliz Anahtar ADI]
from DimProduct